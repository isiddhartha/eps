-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 13, 2014 at 06:41 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pole`
--

-- --------------------------------------------------------

--
-- Table structure for table `current_users`
--

DROP TABLE IF EXISTS `current_users`;
CREATE TABLE IF NOT EXISTS `current_users` (
  `user_id` int(12) NOT NULL,
  `sec_key` text NOT NULL,
  `status` text NOT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `current_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
CREATE TABLE IF NOT EXISTS `project` (
  `proj_id` int(11) NOT NULL,
  `title` char(80) NOT NULL,
  `admin` char(10) NOT NULL,
  `doc` date NOT NULL,
  `type` char(20) NOT NULL,
  `visibility` char(10) NOT NULL,
  `image` char(20) NOT NULL,
  `description` text,
  `lastUpdate` date NOT NULL,
  PRIMARY KEY (`proj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

UPDATE `project` SET `proj_id` = 1,`title` = 'First',`admin` = 'Sid',`doc` = '2013-09-06',`type` = 'sw',`visibility` = 'public',`image` = 'default.jpg',`description` = 'This is the first project',`lastUpdate` = '0000-00-00' WHERE `project`.`proj_id` = 1;
UPDATE `project` SET `proj_id` = 2,`title` = 'Open Project Collaboration Platform',`admin` = 'Sid',`doc` = '2013-09-06',`type` = 'software',`visibility` = 'public',`image` = 'default.jpg',`description` = 'This is a boot strapped project of the platform',`lastUpdate` = '0000-00-00' WHERE `project`.`proj_id` = 2;
UPDATE `project` SET `proj_id` = 3,`title` = 'Platform Extension',`admin` = 'Sid',`doc` = '2013-09-06',`type` = 'SW',`visibility` = 'public',`image` = 'default.jpg',`description` = 'This is a future expansion project',`lastUpdate` = '0000-00-00' WHERE `project`.`proj_id` = 3;
UPDATE `project` SET `proj_id` = 4,`title` = 'Sample project',`admin` = 'Adhith',`doc` = '2013-11-28',`type` = 'Electronics',`visibility` = 'public',`image` = 'default.jpg',`description` = 'This is a dummy project',`lastUpdate` = '0000-00-00' WHERE `project`.`proj_id` = 4;
UPDATE `project` SET `proj_id` = 15,`title` = 'somthing',`admin` = 'me',`doc` = '2014-02-21',`type` = 'electronics',`visibility` = 'public',`image` = '',`description` = 'i duno wat',`lastUpdate` = '0000-00-00' WHERE `project`.`proj_id` = 15;

-- --------------------------------------------------------

--
-- Table structure for table `proj_mem`
--

DROP TABLE IF EXISTS `proj_mem`;
CREATE TABLE IF NOT EXISTS `proj_mem` (
  `proj_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `auth` int(3) NOT NULL,
  PRIMARY KEY (`proj_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proj_mem`
--


-- --------------------------------------------------------

--
-- Table structure for table `proj_prof`
--

DROP TABLE IF EXISTS `proj_prof`;
CREATE TABLE IF NOT EXISTS `proj_prof` (
  `proj_id` int(11) NOT NULL,
  `desc` longtext NOT NULL,
  `tags` mediumtext NOT NULL,
  PRIMARY KEY (`proj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proj_prof`
--

UPDATE `proj_prof` SET `proj_id` = 1,`desc` = '',`tags` = '' WHERE `proj_prof`.`proj_id` = 1;
UPDATE `proj_prof` SET `proj_id` = 2,`desc` = '',`tags` = '' WHERE `proj_prof`.`proj_id` = 2;
UPDATE `proj_prof` SET `proj_id` = 15,`desc` = 'i duno wat',`tags` = 'somting' WHERE `proj_prof`.`proj_id` = 15;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(12) NOT NULL,
  `alias` char(40) NOT NULL,
  `password` char(50) NOT NULL,
  `email` text,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

UPDATE `user` SET `user_id` = 2,`alias` = 'isiddhar',`password` = '*E49CD9A54870E4F60F41AEC6114560EF0F216CC9',`email` = '6isiddhartha@gmail.com' WHERE `user`.`user_id` = 2;

-- --------------------------------------------------------

--
-- Table structure for table `user_prof`
--

DROP TABLE IF EXISTS `user_prof`;
CREATE TABLE IF NOT EXISTS `user_prof` (
  `user_id` int(12) NOT NULL,
  `alias` text NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `dob` date NOT NULL,
  `tel_no` text NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `img` text NOT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_prof`
--

UPDATE `user_prof` SET `user_id` = 2,`alias` = 'isiddhar',`fname` = 'Siddhartha',`lname` = 'Chandrasekar',`dob` = '1992-01-15',`tel_no` = '8220977568',`country` = 'India',`city` = 'Coimbatore',`img` = '' WHERE `user_prof`.`user_id` = 2;
