<?php
/*This script serves as the collection of all common backend scripts used by all modules.
Individually used scripts are called by the respective sub-module script*/
//$ROOT=dirname(__FILE__);
//$ROOT1=$_SERVER['DOCUMENT_ROOT'];
require_once($ROOT.'lib/errormod.php'); //connects to the commom library
require_once($ROOT.'lib/db.php'); //connects to the commom library


?>