<?php
$ROOT = $_SERVER['DOCUMENT_ROOT'];
?>