$(document).ready(function(){
$('.back').click(function() {history.go(-1);});
});