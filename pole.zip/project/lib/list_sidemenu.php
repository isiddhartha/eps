<style type=text/css>
li{margin-bottom:30px;}
a{text-decoration:none;color:#CCC;font:bold 20px Cambria;}
a:hover{color:#999;}
li:hover{background:#CCC;}
</style>
<ul id="sort">
<li><a href="project_list.php?sort=latest">Latest</a></li>
<li><a href="project_list.php?sort=popular">Popular</a></li>
<li><a href="project_list.php?sort=rated">Most Rated</a></li>
<li><a href="project_list.php?sort=active">Most Active</a></li>
</ul>
<?php

?>