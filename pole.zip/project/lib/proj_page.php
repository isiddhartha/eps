<?php
class banner  // This class handles all attributes and methods of the banner in the projects module. This banner is specific for the project module alone.
{

	function banner($banner,$arg_msg) //Constructor to display banner. It can take parameters from the calling function to set up the banner.
	{	
		echo '<div id="banner">';
		if ($banner=='list')
		{
			include("list_banner.php");
		}
		else if ($banner=='profile') 
		{	
			if($arg_msg)
			{
				echo '<h1>'.$arg_msg[1].'</h1></br>';
				echo '<table>';
				echo '<tr><td width="40%">Admin:    '.$arg_msg[2].'</td>';
				echo '<td width="40%">Commenced:    '.$arg_msg[3].'</td>';
				echo '<td>Category:    '.$arg_msg[4].'</td></tr>';
				echo '</table>';
				echo '<p left="100px">Tags:  '.$arg_msg[5].'</p>';
			}
		}
		/*extendable for other modules of the projects module*/
		echo '</div>';
	}
}
/****************************************************************************************************/
class proj_page 
/*Project page class structures the page of the project module. It calls every sub-object and pases arguments to it. It calls the banner class
after the initialization and display of logo. Creates the footer and menu if available.
It takes 3 parameters on initiation:
title--> Title to be displayed on the window
banner--> The module being displayed. Banner is populated in diverse ways for different modules.
arg_msg-->Holds all necessary data for the calling function to work properly. The array is populated according to the context of the called function */  
{
		
	function proj_page($title,$event,$arg_msg)/*A function to initialize the header and set the title*/
	{
		$this->initialize($title);
		echo '<body><div id="base">';
		echo '<div id="head">';
		echo '<div id="logo"><a href="	project/index.php?sort=normal"><img src="/img/logo.png"/></a></div>';
		$ban=new banner($event,$arg_msg); //acesses the banner class, creates a banner object and passes the banner type and argument parameters
		echo '</div>';
		echo '<div id="low">';
		$this->display_sidemenu($event,$arg_msg);
		$this->display_panel($event,$arg_msg);
		echo '</div>';
		$this->display_footer();//display_basic _page
		echo '</div></body>';
		echo '</html>';
	}
	function initialize($title)
	{
		echo '	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />  
				<link rel="stylesheet" href="style/project.css" type="text/css" media="screen" charset="utf-8" />
				<link rel="stylesheet" href="style/grid.css" type="text/css" media="screen" charset="utf-8" />';
		echo '<title>'.$title.'</title></head>';
	}

	/*Function to create the side menu based on arguments received from calling function*/
function display_sidemenu($event,$msg)
{
	echo '<div id="side_menu">';
	switch ($event)
	{
	case 'list':
	include("list_sidemenu.php");
	break;
	default:
	echo "Nothing";
	}
	echo '</div>';
}

/*Function that is configures the panel division of the page based on the contents it is showing.
Module variable contains the specification of the module of project box that needs to displayed. Bye default the list of projects are displayed.*/
	function display_panel($event,$msg)
	{
		echo '<div id="panel">';
		switch ($event)
		{
			case 'profile':
			view_project($msg);
			break;
			case 'list':
			$list=new proj_list($msg);
			$list->grid();
			break;
			case 'error':
			error_project($msg);
			break;
		}
		echo '</div>';
	}



	/*Function to display the footer*/
	function display_footer()
	{
		echo '<div id="footer">';
		echo 'Footer';
		echo '</div>';
	}
}
?>
