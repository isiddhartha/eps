<style type=text/css>
#search{position:absolute; right:30px;}
#search input{height:30px; width:200px; vertical-align:super;}
#srchbut{width:20px;height:20px; margin-top:10px;}
</style>
<div id="search">

<input type="text" name="srch_value">

<a id="srchbut" href="search.php?"><img src="/img/search.png"></a>
</div>
